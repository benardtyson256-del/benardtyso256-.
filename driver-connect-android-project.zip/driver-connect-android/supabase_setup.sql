-- Driver Connect Uganda: run this in Supabase SQL Editor.
-- Public users may submit booking/driver applications, but only admin accounts can read or change records.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.drivers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null check (char_length(full_name) between 2 and 90),
  phone text not null check (char_length(phone) between 5 and 25),
  licence_class text not null,
  experience text not null,
  preferred_area text,
  availability text not null default 'Flexible',
  status text not null default 'new' check (status in ('new','reviewing','contacted','approved','confirmed','rejected','cancelled')),
  verification_status text not null default 'unverified' check (verification_status in ('unverified','under_review','verified','failed')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null check (char_length(customer_name) between 2 and 90),
  customer_phone text not null check (char_length(customer_phone) between 5 and 25),
  service_type text not null,
  pickup_area text not null,
  destination text,
  preferred_at timestamptz,
  details text,
  status text not null default 'new' check (status in ('new','reviewing','contacted','approved','confirmed','rejected','cancelled')),
  assigned_driver_id uuid references public.drivers(id) on delete set null,
  created_at timestamptz not null default now()
);

create or replace function public.is_driver_connect_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'); $$;
revoke all on function public.is_driver_connect_admin() from public;
grant execute on function public.is_driver_connect_admin() to authenticated;

alter table public.profiles enable row level security;
alter table public.bookings enable row level security;
alter table public.drivers enable row level security;

-- Profiles: a signed-in user can read their own role; admins can read profiles.
drop policy if exists "profile owner or admin reads profile" on public.profiles;
create policy "profile owner or admin reads profile" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_driver_connect_admin());

-- Anonymous customer/driver submissions. No public read, update or delete.
drop policy if exists "public can submit bookings" on public.bookings;
create policy "public can submit bookings" on public.bookings for insert to anon, authenticated with check (
  char_length(customer_name) between 2 and 90 and char_length(customer_phone) between 5 and 25
  and status = 'new' and assigned_driver_id is null
);
drop policy if exists "admins manage bookings" on public.bookings;
create policy "admins manage bookings" on public.bookings for all to authenticated
using (public.is_driver_connect_admin()) with check (public.is_driver_connect_admin());

drop policy if exists "public can register drivers" on public.drivers;
create policy "public can register drivers" on public.drivers for insert to anon, authenticated with check (
  char_length(full_name) between 2 and 90 and char_length(phone) between 5 and 25
  and status = 'new' and verification_status = 'unverified'
);
drop policy if exists "admins manage drivers" on public.drivers;
create policy "admins manage drivers" on public.drivers for all to authenticated
using (public.is_driver_connect_admin()) with check (public.is_driver_connect_admin());

grant usage on schema public to anon, authenticated;
grant insert on public.bookings, public.drivers to anon, authenticated;
grant select, update, delete on public.bookings, public.drivers to authenticated;
grant select on public.profiles to authenticated;

-- ADMIN SETUP:
-- 1) Create your user in Supabase Dashboard > Authentication > Users > Add user.
-- 2) Copy that user's UUID.
-- 3) Run this with your actual UUID and full name (replace both placeholders):
-- insert into public.profiles (id, full_name, role)
-- values ('PASTE-AUTH-USER-UUID-HERE', 'Your Name', 'admin');
-- Never put the service_role key in this app. Use only the publishable/anon key.
