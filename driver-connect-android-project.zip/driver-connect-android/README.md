# Driver Connect Uganda — Android + Supabase starter

This project turns the current Driver Connect prototype into an Android WebView app connected to Supabase for hosted authentication and data storage.

## What is included
- Customer booking submissions stored in `public.bookings`.
- Driver applications stored in `public.drivers`.
- Administrator sign-in using Supabase Auth.
- Admin-only record access enforced by PostgreSQL Row Level Security (RLS).
- Admin review/status changes, driver verification status and booking-to-driver assignment.
- Candidate matching list: only approved + verified drivers are offered; preferred work area is compared with the booking pickup area.
- Android Studio project wrapper.

## Important: not yet deployable until configured
The app deliberately contains placeholders for the Supabase project URL and publishable/anon key. A real hosted database and administrator account must be created by the owner. Do not publish or install as a production service until this setup and testing are complete.

## 1. Create the online database
1. Create a Supabase project at https://supabase.com/.
2. In the project, open SQL Editor.
3. Paste and run `supabase_setup.sql`.
4. Open Project Settings / API and copy the Project URL and publishable key (or legacy anon key).
5. Open `app/src/main/assets/index.html` and replace:
   - `YOUR_SUPABASE_PROJECT_URL`
   - `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`
6. Save the file.

## 2. Create your administrator account
1. In Supabase Dashboard > Authentication > Users, add an administrator user with your email and a strong unique password.
2. Copy the user's UUID.
3. In SQL Editor, run the final `insert into public.profiles...` statement from `supabase_setup.sql`, replacing the UUID and name.
4. Keep the password private. Never add the Supabase service_role key to the Android app.

## 3. Build the Android APK
1. Install Android Studio on a Windows, Mac or Linux computer: https://developer.android.com/studio
2. Open this folder in Android Studio (`File > Open`).
3. Allow Android Studio to download the Android Gradle Plugin and dependencies.
4. Select `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. Android Studio will show the APK location. Usually: `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## 4. First test checklist
- Submit a test customer booking from a second device/browser.
- Submit a test driver application.
- Sign in using the admin account on your phone.
- Confirm you can see both records.
- Mark a test driver as `verified` and `approved` only after actually checking their documents and references.
- Assign that driver to a test booking.
- Sign out and confirm admin records are no longer visible.

## Security and operational notes
- Public users can insert booking and driver application records, but cannot read them. Only the admin role can read/update/delete them.
- This initial version does not implement customer/driver accounts, OTP phone verification, file uploads for licences, push notifications, payments, live GPS tracking or Play Store publishing.
- Basic area matching is a suggestion, not proof of availability or suitability. Confirm the driver and trip details directly.
- Add anti-spam/rate limiting and a privacy notice before public launch. Review Uganda's data protection requirements before collecting identity or licence documents.
- The app loads Supabase JS from a CDN, so the phone needs internet access and the CDN must be reachable.

## Phone-only build option (GitHub Actions)
You do not need to install Android Studio if you use GitHub's cloud build service.
1. Create/sign in to a GitHub account in your phone browser: https://github.com/.
2. Create a **private** repository named `driver-connect-uganda`.
3. Upload the contents of this project folder to the repository (the files inside `driver-connect-android`, not the outer folder). Ensure the `.github/workflows/android-apk.yml` file is included. GitHub's mobile website may be easier with your browser's **Desktop site** option enabled.
4. Open the repository's **Actions** tab and select **Build Driver Connect Android APK**. If prompted, enable Actions, then choose **Run workflow**.
5. When the run completes successfully, open that run and download the artifact named `driver-connect-uganda-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager.

This cloud workflow creates a **debug/test APK**, not a Play Store release. Configure Supabase first by following sections 1 and 2 above. Do not put a Supabase service-role key, admin password, or other secret in the app or repository. The publishable/anon key is intended for client use when database Row Level Security is correctly configured.
